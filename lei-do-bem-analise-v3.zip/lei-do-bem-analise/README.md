# Lei do Bem - Apoio à análise preliminar de elegibilidade

Ferramenta de apoio ao analista de P&D do Banco do Nordeste (BNB), desenvolvida no
Hackathon STS 2026. **A IA propõe; o analista decide.**

Base de referência: `docs/base_projeto_v0.2.txt`
Decisão de stack: `docs/adr/0001-stack.md`

## Estado atual (Fase 1, em andamento)

- [x] Máquina de estados dos pontos D1 a D5, com analista identificado, motivo obrigatório e reabertura por dependência
- [x] Schemas do módulo de discordâncias e precedentes internos
- [x] Regra de convergência (revisão cega) e de padrão candidato
- [x] Ingestão de TXT, MD, CSV e JSON (PDF ainda não suportado)
- [x] Divisão em trechos por unidade lógica (cabeçalho ou artigo), com trecho_id estável
- [x] Busca lexical BM25 sem dependências, com filtro por norma ou por projeto
- [x] Verificador de citações: trecho existe, foi recuperado, literal confere e cobertura lexical
- [x] Bloqueio de proposta sem citação ou com citação falha
- [x] Dossiê em Markdown a partir de decisões confirmadas, com referências conferidas
- [ ] Busca semântica (embeddings), aguardando escolha de modelo aprovado
- [ ] Extração de PDF, aguardando biblioteca e PDFs reais
- [ ] Motor de avaliação D1 a D5 e prompts dos critérios, aguardando textos normativos
- [ ] Servidor MCP e API FastAPI
- [ ] Interface React
- [ ] Regressão contra a calibração PRJ01 a PRJ20, aguardando massa de dados

Os dados em `dados/fixtures/` são fictícios e servem só para teste. Não são legislação nem projetos reais.

## Passo a passo de execução

Requisito: Python 3.11 ou superior.

### Windows (PowerShell)

```powershell
# 1. Entrar na pasta do projeto (ajuste o caminho onde você extraiu o zip)
cd C:\projetos\lei-do-bem-analise

# 2. Criar o ambiente virtual (use "py -3.11" se "python" não funcionar)
python -m venv .venv

# 3. Instalar as dependências (pydantic para os schemas, pytest para os testes)
.\.venv\Scripts\python.exe -m pip install pydantic pytest

# 4. Rodar os testes (esperado: 54 passed)
.\.venv\Scripts\python.exe -m pytest -q

# 5. Rodar a demonstração ponta a ponta com dados fictícios
.\.venv\Scripts\python.exe scripts\demo_fluxo.py
```

Se o PowerShell bloquear scripts ao ativar o ambiente, não ative: os comandos
acima chamam o Python do ambiente diretamente, sem precisar de ativação.

### Linux / macOS

```bash
cd lei-do-bem-analise
python3 -m venv .venv
.venv/bin/python -m pip install pydantic pytest
.venv/bin/python -m pytest -q
.venv/bin/python scripts/demo_fluxo.py
```

Ao final da demonstração, o dossiê de exemplo é salvo em `saida/dossie_PRJ-TESTE.md`.
A pasta `saida/` não vai para o git.

O que a demonstração faz, na ordem:

1. Lê a norma e o projeto de exemplo (`dados/fixtures/`).
2. Divide os documentos em trechos, cada um com um `trecho_id`.
3. Busca no projeto os trechos relevantes para a consulta.
4. Verifica a citação da proposta. Se a citação falhar, a proposta é bloqueada.
5. Percorre D1 a D5, com confirmação do analista em cada ponto.
6. Gera o dossiê com as decisões confirmadas.

Observação: a demonstração simula o analista, aceitando todos os pontos. Na
ferramenta real, cada confirmação será feita pela interface.

## Estrutura

```
src/
  decisoes/maquina_estados.py   # estados, transicoes, dependencias, log
  schemas/discordancia.py       # discordancias, revisao cega, precedentes
tests/unit/                     # testes da maquina de estados e das discordancias
docs/                           # base, ADRs
prompts/                        # prompts versionados (ainda vazio)
dados/                          # normas, projetos ficticios, calibracao (ainda vazio)
```

## Regras que não podem ser quebradas

1. Nenhum ponto avança sem decisão explícita do analista.
2. Alterar ou rejeitar exige motivo com pelo menos 20 caracteres.
3. Precedentes internos são não normativos e nunca alteram a classificação.
4. O segundo analista de uma revisão cega é sempre diferente do originador.
5. Apenas dados fictícios no hackathon.
