"""
Demonstracao ponta a ponta com dados FICTICIOS (dados/fixtures).

Passos:
1. Ler a norma de exemplo e o projeto de exemplo.
2. Dividir em trechos com trecho_id estavel.
3. Buscar no projeto.
4. Verificar a citacao da proposta da IA.
5. Percorrer D1 a D5, com confirmacao do analista em cada ponto.
6. Gerar o dossie em saida/.

Uso:
    .venv/bin/python scripts/demo_fluxo.py
"""

from __future__ import annotations

import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from src.decisoes.maquina_estados import (  # noqa: E402
    Ponto,
    PontoDecisao,
    pode_apresentar,
    proximo_ponto_pendente,
)
from src.documentos.modelos import TIPO_NORMA, TIPO_PROJETO  # noqa: E402
from src.dossie.gerador import gerar_dossie  # noqa: E402
from src.ingestao.chunking import dividir  # noqa: E402
from src.ingestao.leitores import ler_documento  # noqa: E402
from src.recuperacao.buscador import Buscador  # noqa: E402
from src.verificacao.citacoes import (  # noqa: E402
    Citacao,
    proposta_tem_base,
    verificar_todas,
)

FIXTURES = RAIZ / "dados" / "fixtures"
SAIDA = RAIZ / "saida"
ANALISTA = "ANL-DEMO"
VERSAO_NORMA = "norma de exemplo fictícia v1 (não é legislação)"


def passo(numero: int, titulo: str) -> None:
    print(f"\n[{numero}] {titulo}")


def main() -> int:
    passo(1, "Leitura dos documentos fictícios")
    norma = ler_documento(
        FIXTURES / "norma_exemplo.md",
        doc_id="norma-exemplo",
        tipo=TIPO_NORMA,
        versao="fictícia-v1",
    )
    projeto = ler_documento(
        FIXTURES / "projeto_exemplo" / "dossie.md",
        doc_id="PRJ-TESTE-dossie",
        tipo=TIPO_PROJETO,
        projeto_id="PRJ-TESTE",
    )
    print(f"    norma: {norma.origem} | projeto: {projeto.origem}")

    passo(2, "Divisao em trechos")
    trechos = dividir(norma) + dividir(projeto)
    por_id = {t.trecho_id: t for t in trechos}
    print(f"    {len(trechos)} trechos gerados")

    passo(3, "Busca no projeto PRJ-TESTE")
    busca = Buscador(trechos)
    consulta = "identificador idempotencia estado anterior"
    achados = busca.projeto("PRJ-TESTE", consulta, k=2)
    recuperados = {t.trecho_id for _, t in achados}
    for pontuacao, trecho in achados:
        print(f"    {trecho.trecho_id} ({trecho.secao}) score={pontuacao:.2f}")
    if not achados:
        print("    nenhum trecho encontrado: encerrando.")
        return 1

    passo(4, "Verificacao da citacao da proposta")
    trecho_base = achados[0][1]
    afirmacao = "O barramento ja possuia mecanismo de idempotencia"
    citacoes = [Citacao(afirmacao=afirmacao, trecho_id=trecho_base.trecho_id)]
    resultados = verificar_todas(citacoes, por_id, recuperados)
    ok, motivo = proposta_tem_base(resultados)
    print(f"    {motivo}")
    if not ok:
        print("    proposta bloqueada: nao sera apresentada ao analista.")
        return 1

    justificativa = {
        "porque": [{"afirmacao": afirmacao, "trecho_id": trecho_base.trecho_id}],
        "como": [
            "Busca lexical no corpus do projeto",
            "Verificacao de citacao contra o trecho recuperado",
        ],
        "evidencias_contrarias": [],
        "lacunas": ["Hipotese inicial nao registrada (dado fictício)"],
    }

    passo(5, "Percurso D1 a D5 com confirmacao do analista")
    propostas = [
        (Ponto.D1, None, "Entendimento do projeto"),
        (Ponto.D2, "novidade", "Atende parcialmente"),
        (Ponto.D3, "atividade-A02", "Pesquisa"),
        (Ponto.D4, None, "Lacuna de hipotese inicial"),
        (Ponto.D5, None, "Com ressalvas"),
    ]
    pontos: list[PontoDecisao] = []
    for ponto_, criterio, valor in propostas:
        pontos.append(PontoDecisao(projeto_id="PRJ-TESTE", ponto=ponto_, criterio=criterio))

    for alvo in pontos:
        pendente = proximo_ponto_pendente(pontos)
        assert pendente is alvo, "a ordem D1 a D5 deve ser respeitada"
        assert pode_apresentar(pontos, alvo.ponto)
        alvo.propor(
            valor=next(v for p, c, v in propostas if p == alvo.ponto and c == alvo.criterio),
            justificativa=justificativa,
        )
        alvo.aceitar(ANALISTA)
        print(f"    {alvo.decision_id}: {alvo.valor_final} (confirmado por {alvo.analista})")

    passo(6, "Geracao do dossie")
    SAIDA.mkdir(exist_ok=True)
    caminho = SAIDA / "dossie_PRJ-TESTE.md"
    texto = gerar_dossie(
        projeto_id="PRJ-TESTE",
        pontos=pontos,
        trechos=por_id,
        versao_norma=VERSAO_NORMA,
        nao_verificado=["Entrevista técnica não conferida (dado fictício)"],
    )
    caminho.write_text(texto, encoding="utf-8")
    print(f"    salvo em: {caminho.relative_to(RAIZ)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
